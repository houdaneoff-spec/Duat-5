package dev.duat;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.math.RotationAxis;

/** Petits outils de dessin et d'animation (coins arrondis, couleurs, lissage). */
public final class Gfx {
    public static float dt = 0.016f;
    private static long last = System.nanoTime();

    private Gfx() {}

    /** A appeler une fois par image. */
    public static void frame() {
        long n = System.nanoTime();
        dt = Math.min(0.1f, (n - last) / 1_000_000_000f);
        last = n;
    }

    public static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    public static float approach(float cur, float target, float speed) {
        float k = 1f - (float) Math.exp(-speed * dt);
        return cur + (target - cur) * k;
    }

    public static float easeOut(float t) {
        t = 1f - clamp01(t);
        return 1f - t * t * t;
    }

    /** Multiplie l'opacite d'une couleur ARGB. */
    public static int a(int argb, float mul) {
        int al = (int) (((argb >>> 24) & 255) * clamp01(mul));
        return (al << 24) | (argb & 0xFFFFFF);
    }

    public static int mix(int c1, int c2, float t) {
        t = clamp01(t);
        int al = (int) (((c1 >>> 24) & 255) * (1 - t) + ((c2 >>> 24) & 255) * t);
        int r = (int) (((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
        int g = (int) (((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
        int b = (int) ((c1 & 255) * (1 - t) + (c2 & 255) * t);
        return (al << 24) | (r << 16) | (g << 8) | b;
    }

    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int col) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { c.fill(x, y, x + w, y + h, col); return; }
        c.fill(x, y + r, x + w, y + h - r, col);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int dx = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            c.fill(x + dx, y + i, x + w - dx, y + i + 1, col);
            c.fill(x + dx, y + h - 1 - i, x + w - dx, y + h - i, col);
        }
    }

    /** Ligne epaisse entre deux points ecran. */
    public static void line(DrawContext c, float x0, float y0, float x1, float y1, int th, int col) {
        float dx = x1 - x0, dy = y1 - y0;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1f) return;
        var m = c.getMatrices();
        m.push();
        m.translate(x0, y0, 0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotation((float) Math.atan2(dy, dx)));
        c.fill(0, 0, (int) len, th, col);
        m.pop();
    }

    /** Le moteur de texte ignore les couleurs quasi transparentes : on saute le dessin. */
    public static void text(DrawContext c, TextRenderer tr, String s, int x, int y, int col) {
        if (((col >>> 24) & 255) < 8) return;
        c.drawTextWithShadow(tr, s, x, y, col);
    }

    public static void text(DrawContext c, TextRenderer tr, Text s, int x, int y, int col) {
        if (((col >>> 24) & 255) < 8) return;
        c.drawTextWithShadow(tr, s, x, y, col);
    }
}
