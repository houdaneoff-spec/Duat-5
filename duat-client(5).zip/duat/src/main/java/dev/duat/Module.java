package dev.duat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final Category category;
    public int key; // code GLFW, 0 = aucun
    public final List<Setting> settings = new ArrayList<>();
    public boolean expanded; // reglages deplies dans le ClickGUI
    public float animToggle, animHover, animExpand; // animations d'interface
    private boolean enabled;

    protected Module(String name, Category category, int key) {
        this.name = name; this.category = category; this.key = key;
    }

    protected Setting add(String n, double min, double max, double step, double def) {
        Setting s = new Setting(n, min, max, step, def);
        settings.add(s);
        return s;
    }

    public boolean isEnabled() { return enabled; }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient mc) {}
    public void onHud(DrawContext ctx, MinecraftClient mc) {}
}
