package dev.duat;

import java.util.Locale;

public class Setting {
    public final String name;
    public final double min, max, step;
    public double value;
    public String[] labels;

    public Setting(String name, double min, double max, double step, double def) {
        this.name = name; this.min = min; this.max = max; this.step = step; this.value = def;
    }

    public Setting labels(String... l) { labels = l; return this; }

    public void set(double v) {
        value = Math.round(Math.max(min, Math.min(max, v)) * 100.0) / 100.0;
    }
    public void inc() { set(value + step); }
    public void dec() { set(value - step); }
    public int asInt() { return (int) Math.round(value); }

    public String display() {
        if (labels != null) return labels[Math.max(0, Math.min(labels.length - 1, asInt()))];
        return step >= 1 ? String.valueOf(asInt()) : String.format(Locale.ROOT, "%.1f", value);
    }
}
