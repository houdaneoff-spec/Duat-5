package dev.duat;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

/** Ecran d'accueil anime, affiche une fois au demarrage, avant le menu principal. */
public class WelcomeScreen extends Screen {
    private static final long FADE_MS = 300;

    private final Screen parent;
    private final long start = System.currentTimeMillis();
    private long leaveAt = -1;
    private float hoverEnter, hoverTheme;
    private final float[] px = new float[80], py = new float[80], ps = new float[80];

    public WelcomeScreen(Screen parent) {
        super(Text.literal("Duat"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        Random r = new Random(11);
        for (int i = 0; i < px.length; i++) { px[i] = r.nextFloat(); py[i] = r.nextFloat(); ps[i] = 0.3f + r.nextFloat(); }
    }

    private int btnY() { return (int) (height * 0.60); }
    private boolean overEnter(double mx, double my) {
        return mx >= width / 2 - 65 && mx < width / 2 + 65 && my >= btnY() && my < btnY() + 22;
    }
    private boolean overTheme(double mx, double my) {
        return mx >= width / 2 - 65 && mx < width / 2 + 65 && my >= btnY() + 30 && my < btnY() + 48;
    }

    private void leave() { if (leaveAt < 0) leaveAt = System.currentTimeMillis(); }

    @Override public void close() { leave(); }
    @Override public boolean shouldCloseOnEsc() { return true; }

    @Override
    public void tick() {
        if (leaveAt > 0 && System.currentTimeMillis() - leaveAt >= FADE_MS) client.setScreen(parent);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        Gfx.frame();
        long now = System.currentTimeMillis();
        float t = (now - start) / 1000f;
        int accent = Theme.accent();
        float pulse = 0.5f + 0.5f * (float) Math.sin(t * 1.2f);

        // fond
        ctx.fill(0, 0, width, height, 0xFF06070B);
        ctx.fillGradient(0, height / 2, width, height, 0x00000000, Gfx.a(accent, 0.20f + 0.08f * pulse));
        ctx.fillGradient(0, 0, width, height / 3, Gfx.a(accent, 0.07f), 0x00000000);
        for (int i = 0; i < px.length; i++) {
            float y = (((py[i] - t * ps[i] * 0.03f) % 1f) + 1f) % 1f;
            float x = px[i] + 0.02f * (float) Math.sin(t * 0.6f + i);
            int sz = ps[i] > 1f ? 2 : 1;
            float tw = 0.4f + 0.6f * (0.5f + 0.5f * (float) Math.sin(t * 2.2f + i * 1.7f));
            ctx.fill((int) (x * width), (int) (y * height), (int) (x * width) + sz, (int) (y * height) + sz, Gfx.a(accent, 0.5f * tw));
        }

        // halo derriere le titre
        int cx = width / 2, ty = (int) (height * 0.20);
        float he = Gfx.easeOut(Gfx.clamp01(t / 1.5f));
        for (int i = 3; i >= 1; i--) {
            int hw = (int) ((90 + i * 30) * he), hh = (int) ((26 + i * 9) * he);
            Gfx.rrect(ctx, cx - hw, ty + 24 - hh, hw * 2, hh * 2, 14, Gfx.a(accent, (0.035f + 0.02f * pulse)));
        }

        // titre lettre par lettre
        String title = "DUAT";
        float sc = 6f;
        int spacing = 8, total = 0;
        int[] cw = new int[title.length()];
        for (int i = 0; i < title.length(); i++) {
            cw[i] = (int) (textRenderer.getWidth(String.valueOf(title.charAt(i))) * sc);
            total += cw[i] + (i > 0 ? spacing : 0);
        }
        int x = cx - total / 2;
        for (int i = 0; i < title.length(); i++) {
            float e = Gfx.easeOut(Gfx.clamp01((t - 0.25f - i * 0.18f) / 0.7f));
            if (e > 0.05f) {
                float shimmer = 0.5f + 0.5f * (float) Math.sin(t * 2f - i);
                int col = Gfx.a(Gfx.mix(0xFFFFFFFF, accent, 0.35f + 0.4f * shimmer), e);
                var mat = ctx.getMatrices();
                mat.push();
                mat.translate((float) x, ty + (1f - e) * 26f, 0f);
                mat.scale(sc, sc, 1f);
                ctx.drawText(textRenderer, String.valueOf(title.charAt(i)), 0, 0, col, true);
                mat.pop();
            }
            x += cw[i] + spacing;
        }

        // ligne sous le titre
        float ue = Gfx.easeOut(Gfx.clamp01((t - 1.3f) / 0.9f));
        int uw = (int) ((total + 20) * ue);
        Gfx.rrect(ctx, cx - uw / 2, ty + 62, uw, 5, 2, Gfx.a(accent, 0.25f));
        Gfx.rrect(ctx, cx - uw / 2, ty + 63, uw, 2, 1, Gfx.a(accent, 0.95f));

        // phrase qui s'ecrit
        String tag = "Client utilitaire  -  solo & serveurs autorises";
        int n = (int) Math.max(0, Math.min(tag.length(), (t - 1.8f) * 28f));
        if (n > 0) {
            String shown = tag.substring(0, n) + (n < tag.length() && (now / 250) % 2 == 0 ? "_" : "");
            Gfx.text(ctx, textRenderer, shown, cx - textRenderer.getWidth(tag) / 2, ty + 78, 0xFFA8A8B4);
        }

        // boutons
        float be = Gfx.easeOut(Gfx.clamp01((t - 2.3f) / 0.6f));
        if (be > 0.02f) {
            hoverEnter = Gfx.approach(hoverEnter, overEnter(mx, my) ? 1f : 0f, 14f);
            hoverTheme = Gfx.approach(hoverTheme, overTheme(mx, my) ? 1f : 0f, 14f);
            int accentDark = (Theme.dim() & 0xFFFFFF) | 0xFF000000;
            int slide = (int) ((1f - be) * 14f);

            int bx = cx - 65, by = btnY() + slide;
            float glow = 0.25f + 0.2f * pulse + 0.4f * hoverEnter;
            Gfx.rrect(ctx, bx - 3, by - 3, 136, 28, 8, Gfx.a(accent, glow * 0.35f * be));
            Gfx.rrect(ctx, bx - 1, by - 1, 132, 24, 6, Gfx.a(accent, (0.5f + 0.5f * hoverEnter) * be));
            Gfx.rrect(ctx, bx, by, 130, 22, 5, Gfx.a(Gfx.mix(0xFF14141A, accentDark, hoverEnter), be));
            String enter = "Entrer";
            Gfx.text(ctx, textRenderer, enter, cx - textRenderer.getWidth(enter) / 2, by + 7,
                    Gfx.a(Gfx.mix(0xFFDDDDE4, accent, hoverEnter), be));

            int ty2 = btnY() + 30 + slide;
            Gfx.rrect(ctx, bx, ty2, 130, 18, 4, Gfx.a(Gfx.mix(0xFF101015, 0xFF1E1E26, hoverTheme), be));
            Gfx.rrect(ctx, bx + 6, ty2 + 6, 6, 6, 3, Gfx.a(accent, be));
            Gfx.text(ctx, textRenderer, "Theme : " + Theme.current.label, bx + 18, ty2 + 5, Gfx.a(0xFFB8B8C2, be));
        }

        // pied de page
        float fe = Gfx.easeOut(Gfx.clamp01((t - 2.8f) / 0.6f));
        String foot = "En jeu : touche +  ouvre le menu   |   Minecraft 1.21.4";
        Gfx.text(ctx, textRenderer, foot, cx - textRenderer.getWidth(foot) / 2, height - 18, Gfx.a(0xFF6A6A78, fe));

        // fondu de sortie
        if (leaveAt > 0) ctx.fill(0, 0, width, height, Gfx.a(0xFF000000, Gfx.clamp01((now - leaveAt) / (float) FADE_MS)));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (leaveAt > 0) return true;
        if (button == 0 && overEnter(mx, my)) { leave(); return true; }
        if (button == 0 && overTheme(mx, my)) { Theme.next(); Config.save(); return true; }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER || keyCode == GLFW.GLFW_KEY_SPACE) {
            leave();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
