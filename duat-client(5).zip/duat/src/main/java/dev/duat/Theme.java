package dev.duat;

public enum Theme {
    OR("Or", 0xFFD4AF37),
    BLEU("Bleu", 0xFF4DA6FF),
    ROUGE("Rouge", 0xFFE05555),
    VERT("Vert", 0xFF55C878),
    VIOLET("Violet", 0xFFA070E0),
    ROSE("Rose", 0xFFE070B0);

    public static Theme current = OR;

    public final String label;
    public final int color;

    Theme(String label, int color) { this.label = label; this.color = color; }

    public static int accent() { return current.color; }

    /** Version sombre de la couleur, pour le fond des modules actifs. */
    public static int dim() {
        int c = current.color;
        int r = ((c >> 16) & 255) / 4, g = ((c >> 8) & 255) / 4, b = (c & 255) / 4;
        return 0xE0000000 | (r << 16) | (g << 8) | b;
    }

    public static void next() {
        Theme[] v = values();
        current = v[(current.ordinal() + 1) % v.length];
    }
}
