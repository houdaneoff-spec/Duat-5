package dev.duat;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.text.Text;

public class DuatClient implements ClientModInitializer {
    private static boolean welcomeShown;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();

        // ecran d'accueil : une seule fois, quand le menu principal s'ouvre
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof TitleScreen && !welcomeShown) {
                welcomeShown = true;
                client.execute(() -> client.setScreen(new WelcomeScreen(screen)));
            }
        });

        // /duatnom <pseudo> : choisit le faux pseudo (affiche seulement chez toi)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("duatnom")
                        .then(ClientCommandManager.argument("pseudo", StringArgumentType.word())
                                .executes(c -> {
                                    Modules.FakeName.fake = StringArgumentType.getString(c, "pseudo");
                                    Config.save();
                                    c.getSource().sendFeedback(Text.literal(
                                            "[Duat] Faux pseudo : " + Modules.FakeName.fake
                                                    + " (visible seulement sur ton ecran)"));
                                    return 1;
                                }))));
    }
}
