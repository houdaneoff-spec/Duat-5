package dev.duat;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public final class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();
    private static final Set<Integer> down = new HashSet<>();

    private ModuleManager() {}

    public static void init() {
        MODULES.add(new Modules.AutoTotem());
        MODULES.add(new Modules.AutoCrystal());
        MODULES.add(new Modules.AutoAnchor());
        MODULES.add(new Modules.AutoClicker());
        MODULES.add(new Modules.Sprint());
        MODULES.add(new Modules.Fly());
        MODULES.add(new Modules.Fullbright());
        MODULES.add(new Modules.GlowESP());
        MODULES.add(new Modules.Xray());
        MODULES.add(new Modules.Freecam());
        MODULES.add(new Modules.Zoom());
        MODULES.add(new Modules.SeeInvisible());
        MODULES.add(new Modules.FpsBoost());
        MODULES.add(new Modules.Tracers());
        MODULES.add(new Modules.Info());
        MODULES.add(new Modules.AutoEat());
        MODULES.add(new Modules.AutoDropper());
        MODULES.add(new Modules.FakeName());
        MODULES.add(new Modules.AutoRespawn());
        Config.load();
        ClientTickEvents.END_CLIENT_TICK.register(ModuleManager::tick);
        HudRenderCallback.EVENT.register(ModuleManager::renderHud);
    }

    private static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) {
            // quitter un monde coupe tous les modules
            for (Module m : MODULES) if (m.isEnabled()) m.toggle();
            return;
        }
        long w = mc.getWindow().getHandle();
        if (mc.currentScreen == null) {
            Runnable open = () -> mc.setScreen(new ClickGui());
            press(w, GLFW.GLFW_KEY_KP_ADD, open); // + du pave numerique
            press(w, GLFW.GLFW_KEY_EQUAL, open);  // touche =/+ du clavier (AZERTY : Maj + =)
            for (Module m : MODULES) if (m.key > 0) press(w, m.key, m::toggle);
        }
        for (Module m : MODULES) if (m.isEnabled()) m.onTick(mc);
    }

    private static void press(long window, int key, Runnable action) {
        boolean pressed = InputUtil.isKeyPressed(window, key);
        if (pressed && down.add(key)) action.run();
        else if (!pressed) down.remove(key);
    }

    private static void renderHud(DrawContext ctx, RenderTickCounter tc) {
        Gfx.frame();
        var mc = MinecraftClient.getInstance();
        for (Module m : MODULES) m.animToggle = Gfx.approach(m.animToggle, m.isEnabled() ? 1f : 0f, 10f);
        if (mc.options.hudHidden) return;
        var tr = mc.textRenderer;
        int accent = Theme.accent();
        ctx.drawTextWithShadow(tr, Text.literal("Duat").formatted(Formatting.BOLD), 4, 4, accent);
        ctx.fill(4, 14, 4 + tr.getWidth("Duat"), 15, Gfx.a(accent, 0.8f));

        for (Module m : MODULES) if (m.isEnabled()) m.onHud(ctx, mc);

        List<Module> active = new ArrayList<>();
        for (Module m : MODULES) if (m.animToggle > 0.02f) active.add(m);
        active.sort(Comparator.comparingInt((Module m) -> tr.getWidth(m.name)).reversed());

        int y = 4, sw = ctx.getScaledWindowWidth();
        for (Module m : active) {
            float e = Gfx.easeOut(m.animToggle);
            int w = tr.getWidth(m.name);
            int slide = (int) ((1f - e) * (w + 14));
            int x0 = sw - w - 10 + slide;
            ctx.fill(x0, y, sw + slide, y + 12, Gfx.a(0xFF000000, 0.6f * e));
            ctx.fillGradient(x0 - 6, y, x0, y + 12, 0x00000000, Gfx.a(0xFF000000, 0.6f * e));
            ctx.fill(sw - 2 + slide, y, sw + slide, y + 12, Gfx.a(accent, e));
            Gfx.text(ctx, tr, m.name, x0 + 4, y + 2, Gfx.a(accent, e));
            y += Math.round(13 * e);
        }
    }
}
