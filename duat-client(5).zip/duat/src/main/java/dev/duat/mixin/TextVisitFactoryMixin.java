package dev.duat.mixin;

import dev.duat.Modules;
import net.minecraft.text.TextVisitFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Remplace ton vrai pseudo par le faux dans tous les textes AFFICHES chez toi (rien n'est envoye au serveur). */
@Mixin(TextVisitFactory.class)
public class TextVisitFactoryMixin {
    @ModifyVariable(
            method = "visitFormatted(Ljava/lang/String;Lnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z",
            at = @At("HEAD"), argsOnly = true)
    private static String duat$fakeName(String text) {
        return Modules.FakeName.apply(text);
    }
}
