package dev.duat;

import com.mojang.authlib.GameProfile;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;

/** Tous les modules. Pour un usage solo / serveur perso / serveur qui autorise les mods. */
public final class Modules {
    private Modules() {}

    static int findHotbar(PlayerEntity p, Predicate<ItemStack> f) {
        for (int i = 0; i < 9; i++) if (f.test(p.getInventory().getStack(i))) return i;
        return -1;
    }

    /* ======================= COMBAT ======================= */

    /** Remet un totem dans la main secondaire des qu'elle est vide. */
    public static class AutoTotem extends Module {
        public AutoTotem() { super("AutoTotem", Category.COMBAT, 0); }
        @Override public void onTick(MinecraftClient mc) {
            var p = mc.player;
            if (mc.currentScreen != null || p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
            for (int i = 0; i < 36; i++) {
                if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                    int slot = i < 9 ? 36 + i : i;
                    mc.interactionManager.clickSlot(0, slot, 40, SlotActionType.SWAP, p);
                    return;
                }
            }
        }
    }

    /** Pose un cristal sur l'obsidienne visee et casse les cristaux proches. Delai fixe. */
    public static class AutoCrystal extends Module {
        private final Setting delay = add("Delai", 1, 10, 1, 4);
        private final Setting range = add("Portee", 2, 6, 0.5, 4.5);
        private final Setting minHp = add("Sante", 0, 20, 1, 8);
        private int timer;
        public AutoCrystal() { super("AutoCrystal", Category.COMBAT, 0); }
        @Override public void onTick(MinecraftClient mc) {
            var p = mc.player;
            if (mc.currentScreen != null || p.getHealth() < minHp.value) return;
            if (++timer < delay.asInt()) return;
            timer = 0;

            double r2 = range.value * range.value;
            EndCrystalEntity target = null;
            double best = r2;
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof EndCrystalEntity c) {
                    double d = p.squaredDistanceTo(c);
                    if (d <= best) { best = d; target = c; }
                }
            }
            if (target != null) {
                mc.interactionManager.attackEntity(p, target);
                p.swingHand(Hand.MAIN_HAND);
                return;
            }
            if (p.getMainHandStack().isOf(Items.END_CRYSTAL)
                    && mc.crosshairTarget instanceof BlockHitResult hit
                    && hit.getType() == HitResult.Type.BLOCK) {
                Block b = mc.world.getBlockState(hit.getBlockPos()).getBlock();
                if (b == Blocks.OBSIDIAN || b == Blocks.BEDROCK) {
                    BlockPos above = hit.getBlockPos().up();
                    if (mc.world.getBlockState(above).isAir()
                            && mc.world.getBlockState(above.up()).isAir()
                            && mc.world.getEntitiesByClass(EndCrystalEntity.class, new Box(above), e -> true).isEmpty()) {
                        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
                    }
                }
            }
        }
    }

    /** Charge en glowstone l'ancre de respawn visee. Ne la fait JAMAIS exploser. */
    public static class AutoAnchor extends Module {
        private final Setting delay = add("Delai", 1, 10, 1, 4);
        private int timer;
        public AutoAnchor() { super("AutoAnchor", Category.COMBAT, 0); }
        @Override public void onTick(MinecraftClient mc) {
            var p = mc.player;
            if (mc.currentScreen != null || ++timer < delay.asInt()) return;
            timer = 0;
            if (mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
                BlockState st = mc.world.getBlockState(hit.getBlockPos());
                if (st.isOf(Blocks.RESPAWN_ANCHOR) && st.get(RespawnAnchorBlock.CHARGES) < 4) {
                    int slot = findHotbar(p, s -> s.isOf(Items.GLOWSTONE));
                    if (slot >= 0) {
                        p.getInventory().selectedSlot = slot;
                        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
                    }
                }
            }
        }
    }

    /** Clique automatiquement sur l'entite visee tant que tu maintiens le clic gauche. Cadence fixe. */
    public static class AutoClicker extends Module {
        private final Setting cps = add("CPS", 1, 20, 1, 10);
        private int timer;
        public AutoClicker() { super("AutoClicker", Category.COMBAT, 0); }
        @Override public void onTick(MinecraftClient mc) {
            if (mc.currentScreen != null || !mc.options.attackKey.isPressed()) { timer = 0; return; }
            int interval = Math.max(1, (int) Math.round(20.0 / cps.value));
            if (++timer < interval) return;
            timer = 0;
            if (mc.crosshairTarget instanceof EntityHitResult hit) {
                mc.interactionManager.attackEntity(mc.player, hit.getEntity());
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }

    /* ======================= MOVEMENT ======================= */

    public static class Sprint extends Module {
        public Sprint() { super("Sprint", Category.MOVEMENT, GLFW.GLFW_KEY_R); }
        @Override public void onTick(MinecraftClient mc) {
            var p = mc.player;
            if (p.input.movementForward > 0 && !p.horizontalCollision) p.setSprinting(true);
        }
    }

    public static class Fly extends Module {
        private final Setting speed = add("Vitesse", 0.1, 2.0, 0.1, 0.6);
        public Fly() { super("Fly", Category.MOVEMENT, GLFW.GLFW_KEY_G); }
        @Override public void onTick(MinecraftClient mc) {
            var p = mc.player;
            double yaw = Math.toRadians(p.getYaw());
            double fwd = p.input.movementForward, side = p.input.movementSideways;
            double x = (-Math.sin(yaw) * fwd + Math.cos(yaw) * side) * speed.value;
            double z = ( Math.cos(yaw) * fwd + Math.sin(yaw) * side) * speed.value;
            double y = 0;
            if (mc.options.jumpKey.isPressed()) y += speed.value;
            if (mc.options.sneakKey.isPressed()) y -= speed.value;
            p.setVelocity(new Vec3d(x, y, z));
            p.fallDistance = 0;
        }
    }

    /* ======================= RENDER ======================= */

    public static class Fullbright extends Module {
        public Fullbright() { super("Fullbright", Category.RENDER, GLFW.GLFW_KEY_B); }
        @Override public void onTick(MinecraftClient mc) {
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
        }
        @Override public void onDisable() {
            var mc = MinecraftClient.getInstance();
            if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    public static class GlowESP extends Module {
        public GlowESP() { super("GlowESP", Category.RENDER, GLFW.GLFW_KEY_H); }
        @Override public void onTick(MinecraftClient mc) {
            for (Entity e : mc.world.getEntities())
                if (e instanceof PlayerEntity && e != mc.player) e.setGlowing(true);
        }
        @Override public void onDisable() {
            var mc = MinecraftClient.getInstance();
            if (mc.world == null) return;
            for (Entity e : mc.world.getEntities())
                if (e instanceof PlayerEntity) e.setGlowing(false);
        }
    }

    /** Xray : ne dessine que les minerais (via BlockMixin). Surtout utile en solo. */
    public static class Xray extends Module {
        public static boolean active;
        public static final Set<Block> ORES = Set.of(
                Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE,
                Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE,
                Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE,
                Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE,
                Blocks.NETHER_GOLD_ORE, Blocks.NETHER_QUARTZ_ORE, Blocks.ANCIENT_DEBRIS, Blocks.SPAWNER);
        public Xray() { super("Xray", Category.RENDER, GLFW.GLFW_KEY_X); }
        @Override public void onEnable() {
            active = true;
            var mc = MinecraftClient.getInstance();
            if (mc.world != null) mc.worldRenderer.reload();
        }
        @Override public void onTick(MinecraftClient mc) {
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
        }
        @Override public void onDisable() {
            active = false;
            var mc = MinecraftClient.getInstance();
            if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            if (mc.world != null) mc.worldRenderer.reload();
        }
    }

    /** Camera libre : ton personnage reste fige, la camera se deplace. */
    public static class Freecam extends Module {
        private final Setting speed = add("Vitesse", 0.1, 2.0, 0.1, 0.8);
        private OtherClientPlayerEntity cam;
        private Vec3d origin, camPos;
        public Freecam() { super("Freecam", Category.RENDER, GLFW.GLFW_KEY_V); }
        @Override public void onEnable() {
            var mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;
            var p = mc.player;
            origin = p.getPos();
            camPos = p.getEyePos();
            cam = new OtherClientPlayerEntity(mc.world, new GameProfile(UUID.randomUUID(), "Freecam"));
            cam.refreshPositionAndAngles(camPos.x, camPos.y, camPos.z, p.getYaw(), p.getPitch());
            cam.noClip = true;
            mc.world.addEntity(cam);
            mc.setCameraEntity(cam);
        }
        @Override public void onTick(MinecraftClient mc) {
            if (cam == null) return;
            var p = mc.player;
            p.setPosition(origin);
            p.setVelocity(Vec3d.ZERO);
            double yaw = Math.toRadians(p.getYaw()), pitch = Math.toRadians(p.getPitch());
            Vec3d look = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
            Vec3d right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
            Vec3d mv = Vec3d.ZERO;
            if (mc.options.forwardKey.isPressed()) mv = mv.add(look);
            if (mc.options.backKey.isPressed()) mv = mv.subtract(look);
            if (mc.options.rightKey.isPressed()) mv = mv.add(right);
            if (mc.options.leftKey.isPressed()) mv = mv.subtract(right);
            if (mc.options.jumpKey.isPressed()) mv = mv.add(0, 1, 0);
            if (mc.options.sneakKey.isPressed()) mv = mv.add(0, -1, 0);
            if (mv.lengthSquared() > 0) camPos = camPos.add(mv.normalize().multiply(speed.value));
            cam.refreshPositionAndAngles(camPos.x, camPos.y, camPos.z, p.getYaw(), p.getPitch());
        }
        @Override public void onDisable() {
            var mc = MinecraftClient.getInstance();
            if (mc.player != null) {
                mc.setCameraEntity(mc.player);
                if (origin != null) mc.player.setPosition(origin);
            }
            if (cam != null && mc.world != null) mc.world.removeEntity(cam.getId(), Entity.RemovalReason.DISCARDED);
            cam = null;
        }
    }

    public static class Zoom extends Module {
        private final Setting fov = add("FOV", 30, 90, 5, 30);
        private int old = 70;
        public Zoom() { super("Zoom", Category.RENDER, GLFW.GLFW_KEY_C); }
        @Override public void onEnable() { old = MinecraftClient.getInstance().options.getFov().getValue(); }
        @Override public void onTick(MinecraftClient mc) { mc.options.getFov().setValue(fov.asInt()); }
        @Override public void onDisable() { MinecraftClient.getInstance().options.getFov().setValue(old); }
    }

    /** Affiche les joueurs invisibles (effet ou potion). */
    public static class SeeInvisible extends Module {
        public SeeInvisible() { super("SeeInvisible", Category.RENDER, 0); }
        @Override public void onTick(MinecraftClient mc) {
            for (Entity e : mc.world.getEntities())
                if (e instanceof PlayerEntity && e.isInvisible()) e.setInvisible(false);
        }
    }

    /** Baisse les reglages graphiques pour gagner des FPS, et les remet a la desactivation. */
    public static class FpsBoost extends Module {
        private final Setting dist = add("Distance", 2, 12, 1, 6);
        private int oldDist, oldBlend;
        private ParticlesMode oldParticles;
        private boolean oldShadows;
        private CloudRenderMode oldClouds;
        public FpsBoost() { super("FpsBoost", Category.RENDER, 0); }
        @Override public void onEnable() {
            var o = MinecraftClient.getInstance().options;
            oldDist = o.getViewDistance().getValue();
            oldParticles = o.getParticles().getValue();
            oldShadows = o.getEntityShadows().getValue();
            oldClouds = o.getCloudRenderMode().getValue();
            oldBlend = o.getBiomeBlendRadius().getValue();
            o.getViewDistance().setValue(dist.asInt());
            o.getParticles().setValue(ParticlesMode.MINIMAL);
            o.getEntityShadows().setValue(false);
            o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            o.getBiomeBlendRadius().setValue(0);
        }
        @Override public void onDisable() {
            var o = MinecraftClient.getInstance().options;
            o.getViewDistance().setValue(oldDist);
            o.getParticles().setValue(oldParticles);
            o.getEntityShadows().setValue(oldShadows);
            o.getCloudRenderMode().setValue(oldClouds);
            o.getBiomeBlendRadius().setValue(oldBlend);
        }
    }

    /** Coordonnees, FPS et direction a l'ecran. */
    public static class Info extends Module {
        public Info() { super("Infos", Category.RENDER, 0); }
        @Override public void onHud(DrawContext ctx, MinecraftClient mc) {
            var p = mc.player;
            if (p == null) return;
            String dir = switch (p.getHorizontalFacing()) {
                case NORTH -> "Nord";
                case SOUTH -> "Sud";
                case EAST -> "Est";
                case WEST -> "Ouest";
                default -> "?";
            };
            String[] lines = {
                    "XYZ  " + p.getBlockX() + "  " + p.getBlockY() + "  " + p.getBlockZ(),
                    "FPS  " + mc.getCurrentFps(),
                    "Dir  " + dir };
            int y = 18;
            for (String l : lines) { ctx.drawTextWithShadow(mc.textRenderer, l, 4, y, 0xFFFFFFFF); y += 11; }
        }
    }

    /* ======================= PLAYER ======================= */

    public static class AutoRespawn extends Module {
        public AutoRespawn() { super("AutoRespawn", Category.PLAYER, 0); }
        @Override public void onTick(MinecraftClient mc) {
            if (mc.player.isDead()) mc.player.requestRespawn();
        }
    }

    /** Mange tout seul quand la faim passe sous le seuil. Cherche la nourriture dans la barre d'objets. */
    public static class AutoEat extends Module {
        private static final Set<Item> SKIP = Set.of(Items.ROTTEN_FLESH, Items.SPIDER_EYE, Items.PUFFERFISH,
                Items.POISONOUS_POTATO, Items.CHORUS_FRUIT, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE);
        private final Setting hunger = add("Faim", 1, 19, 1, 14);
        private boolean eating;
        private int prevSlot = -1;
        public AutoEat() { super("AutoEat", Category.PLAYER, 0); }

        private static boolean isFood(ItemStack s) {
            return !s.isEmpty() && s.get(DataComponentTypes.FOOD) != null && !SKIP.contains(s.getItem());
        }

        @Override public void onTick(MinecraftClient mc) {
            var p = mc.player;
            int food = p.getHungerManager().getFoodLevel();
            if (eating) {
                if (food >= 20 || !isFood(p.getMainHandStack()) || mc.currentScreen != null) stop();
                return;
            }
            if (mc.currentScreen != null || food > hunger.asInt()) return;
            int slot = findHotbar(p, AutoEat::isFood);
            if (slot < 0) return;
            prevSlot = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = slot;
            mc.options.useKey.setPressed(true);
            eating = true;
        }

        private void stop() {
            var mc = MinecraftClient.getInstance();
            mc.options.useKey.setPressed(false);
            if (mc.player != null && prevSlot >= 0) mc.player.getInventory().selectedSlot = prevSlot;
            prevSlot = -1;
            eating = false;
        }

        @Override public void onDisable() { if (eating) stop(); }
    }

    /* ======================= NOUVEAUX ======================= */

    /** Ligne rouge depuis le bas de l'ecran vers chaque entite (visible a travers les murs). */
    public static class Tracers extends Module {
        private final Setting range = add("Portee", 10, 200, 10, 64);
        private final Setting thick = add("Epaisseur", 1, 3, 1, 1);
        private final Setting target = add("Cible", 0, 1, 1, 0).labels("Tout", "Joueurs");
        public Tracers() { super("Tracers", Category.RENDER, GLFW.GLFW_KEY_J); }

        @Override public void onHud(DrawContext ctx, MinecraftClient mc) {
            var p = mc.player;
            if (p == null || mc.world == null) return;
            var cam = mc.gameRenderer.getCamera();
            Vec3d cp = cam.getPos();
            double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
            double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
            double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
            double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;
            double tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
            int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
            double aspect = (double) sw / sh;
            float delta = mc.getRenderTickCounter().getTickDelta(true);
            float x0 = sw / 2f, y0 = sh - 2f;

            for (Entity e : mc.world.getEntities()) {
                if (e == p || e == mc.getCameraEntity() || e.isRemoved()) continue;
                if (!(e instanceof LivingEntity) || e instanceof ArmorStandEntity) continue;
                if (target.asInt() == 1 && !(e instanceof PlayerEntity)) continue;
                Vec3d pos = e.getLerpedPos(delta).add(0, e.getHeight() / 2.0, 0);
                double dist = pos.distanceTo(cp);
                if (dist > range.value) continue;
                Vec3d d = pos.subtract(cp);
                double cx = d.x * rx + d.z * rz;
                double cy = d.x * ux + d.y * uy + d.z * uz;
                double cz = d.x * fx + d.y * fy + d.z * fz;
                float tx, ty;
                if (cz > 0.1) {
                    tx = (float) (sw / 2.0 * (1 + cx / (cz * tanHalf * aspect)));
                    ty = (float) (sh / 2.0 * (1 - cy / (cz * tanHalf)));
                } else { // derriere toi : la ligne pointe vers le bord de l'ecran
                    double dx = cx, dy = -cy, len = Math.hypot(dx, dy);
                    if (len < 1e-6) { dx = 0; dy = 1; len = 1; }
                    dx /= len; dy /= len;
                    double k = Math.min(dx == 0 ? 1e9 : (sw / 2.0 - 6) / Math.abs(dx),
                                        dy == 0 ? 1e9 : (sh / 2.0 - 6) / Math.abs(dy));
                    tx = (float) (sw / 2.0 + dx * k);
                    ty = (float) (sh / 2.0 + dy * k);
                }
                tx = Math.max(-4000f, Math.min(4000f, tx));
                ty = Math.max(-4000f, Math.min(4000f, ty));
                float alpha = (float) Math.max(0.35, 1.0 - dist / range.value * 0.6);
                int col = Gfx.a(0xFFFF3030, alpha);
                Gfx.line(ctx, x0, y0, tx, ty, thick.asInt(), col);
                ctx.fill((int) tx - 2, (int) ty - 2, (int) tx + 2, (int) ty + 2, col);
            }
        }
    }

    /** Lache tout de suite l'objet que tu tiens en main. */
    public static class AutoDropper extends Module {
        private final Setting delay = add("Delai", 1, 20, 1, 1);
        private int timer;
        public AutoDropper() { super("AutoDropper", Category.PLAYER, 0); }
        @Override public void onTick(MinecraftClient mc) {
            var p = mc.player;
            if (mc.currentScreen != null || p.getMainHandStack().isEmpty()) return;
            if (++timer < delay.asInt()) return;
            timer = 0;
            p.dropSelectedItem(true);
        }
    }

    /** Faux pseudo visible UNIQUEMENT sur ton ecran (texte remplace par TextVisitFactoryMixin). */
    public static class FakeName extends Module {
        public static boolean active;
        public static String fake = "Herobrine";
        private static String real;
        public FakeName() { super("FakeName", Category.PLAYER, 0); }
        @Override public void onEnable() { active = true; }
        @Override public void onDisable() { active = false; }

        public static String apply(String text) {
            if (!active || text == null || fake == null) return text;
            if (real == null) {
                var mc = MinecraftClient.getInstance();
                if (mc == null || mc.getSession() == null) return text;
                real = mc.getSession().getUsername();
            }
            if (real == null || real.isEmpty() || !text.contains(real)) return text;
            return text.replace(real, fake);
        }
    }
}
