package dev.duat;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Sauvegarde : theme, touches et reglages. L'etat active/desactive n'est volontairement pas sauvegarde. */
public final class Config {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("duat.properties");

    private Config() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        Properties p = new Properties();
        try (var in = Files.newInputStream(FILE)) { p.load(in); } catch (IOException e) { return; }
        try {
            Theme.current = Theme.values()[Integer.parseInt(p.getProperty("theme", "0"))];
        } catch (RuntimeException ignored) {}
        String fn = p.getProperty("fakename");
        if (fn != null && !fn.isBlank()) Modules.FakeName.fake = fn;
        for (Module m : ModuleManager.MODULES) {
            try {
                String k = p.getProperty(m.name + ".key");
                if (k != null) m.key = Integer.parseInt(k);
                for (Setting s : m.settings) {
                    String v = p.getProperty(m.name + "." + s.name);
                    if (v != null) s.set(Double.parseDouble(v));
                }
            } catch (RuntimeException ignored) {}
        }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("theme", String.valueOf(Theme.current.ordinal()));
        p.setProperty("fakename", Modules.FakeName.fake);
        for (Module m : ModuleManager.MODULES) {
            p.setProperty(m.name + ".key", String.valueOf(m.key));
            for (Setting s : m.settings) p.setProperty(m.name + "." + s.name, String.valueOf(s.value));
        }
        try (var out = Files.newOutputStream(FILE)) { p.store(out, "Duat Client"); } catch (IOException ignored) {}
    }
}
