package dev.duat;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public class ClickGui extends Screen {
    private static final int PW = 120, HH = 20, RH = 16, GAP = 10;
    private static final Map<Category, int[]> POS = new EnumMap<>(Category.class);

    private record Row(int x, int y, int w, int h, Module m, Setting s, int clipB) {
        boolean hit(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < Math.min(y + h, clipB);
        }
    }

    private final Map<Category, Integer> bottoms = new EnumMap<>(Category.class);
    private final float[] ptX = new float[45], ptY = new float[45], ptS = new float[45];
    private float open;
    private String query = "";
    private Category dragCat;
    private int dragDX, dragDY;
    private Setting slider;
    private int slX, slW;

    public ClickGui() { super(Text.literal("Duat")); }

    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { Config.save(); }

    @Override
    protected void init() {
        if (POS.isEmpty()) {
            int n = Category.values().length;
            int x0 = Math.max(10, (width - (n * (PW + GAP) - GAP)) / 2);
            int i = 0;
            for (Category c : Category.values()) POS.put(c, new int[]{x0 + i++ * (PW + GAP), 46});
        }
        Random r = new Random(3);
        for (int i = 0; i < ptX.length; i++) { ptX[i] = r.nextFloat(); ptY[i] = r.nextFloat(); ptS[i] = 0.4f + r.nextFloat(); }
    }

    private boolean matches(Module m) {
        return query.isEmpty() || m.name.toLowerCase(Locale.ROOT).contains(query);
    }

    private List<Row> rows() {
        List<Row> out = new ArrayList<>();
        bottoms.clear();
        for (Category c : Category.values()) {
            int[] p = POS.get(c);
            int x = p[0], y = p[1] + HH + 2;
            for (Module m : ModuleManager.MODULES) {
                if (m.category != c || !matches(m)) continue;
                out.add(new Row(x, y, PW, RH, m, null, y + RH));
                y += RH;
                if (!m.settings.isEmpty() && m.animExpand > 0.005f) {
                    int total = m.settings.size() * RH;
                    int vis = Math.round(total * Gfx.easeOut(m.animExpand));
                    int yy = y;
                    for (Setting s : m.settings) { out.add(new Row(x, yy, PW, RH, m, s, y + vis)); yy += RH; }
                    y += vis;
                }
            }
            bottoms.put(c, y + 4);
        }
        return out;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        open = Math.min(1f, open + Gfx.dt * 3.2f);
        float eo = Gfx.easeOut(open);
        int accent = Theme.accent();
        int accentDark = (Theme.dim() & 0xFFFFFF) | 0xFF000000;
        for (Module m : ModuleManager.MODULES) m.animExpand = Gfx.approach(m.animExpand, m.expanded ? 1f : 0f, 12f);

        // fond
        ctx.fillGradient(0, 0, width, height, Gfx.a(0xFF05060A, 0.72f * eo), Gfx.a(accentDark, 0.85f * eo));
        float t = System.currentTimeMillis() / 1000f;
        for (int i = 0; i < ptX.length; i++) {
            float y = (((ptY[i] - t * ptS[i] * 0.02f) % 1f) + 1f) % 1f;
            float x = ptX[i] + 0.015f * (float) Math.sin(t * 0.5f + i);
            int px = (int) (x * width), py = (int) (y * height), sz = ptS[i] > 1f ? 2 : 1;
            float tw = 0.5f + 0.5f * (float) Math.sin(t * 2f + i);
            ctx.fill(px, py, px + sz, py + sz, Gfx.a(accent, 0.4f * eo * tw));
        }

        // barre du haut : theme, recherche, aide
        boolean hoverTheme = mx >= 10 && mx < 120 && my >= 10 && my < 28;
        Gfx.rrect(ctx, 10, 10, 110, 18, 4, Gfx.a(hoverTheme ? 0xFF22222A : 0xFF14141A, eo));
        Gfx.rrect(ctx, 16, 16, 6, 6, 3, Gfx.a(accent, eo));
        Gfx.text(ctx, textRenderer, "Theme : " + Theme.current.label, 28, 15, Gfx.a(0xFFDDDDE4, eo));

        int sx = width / 2 - 90;
        Gfx.rrect(ctx, sx, 10, 180, 18, 4, Gfx.a(0xFF14141A, eo));
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        if (query.isEmpty()) Gfx.text(ctx, textRenderer, "Rechercher un module...", sx + 8, 15, Gfx.a(0xFF6A6A75, eo));
        else Gfx.text(ctx, textRenderer, query + (blink ? "_" : ""), sx + 8, 15, Gfx.a(0xFFFFFFFF, eo));

        String help = "Clic droit : reglages   Glisser : deplacer";
        Gfx.text(ctx, textRenderer, help, width - 10 - textRenderer.getWidth(help), 15, Gfx.a(0xFF77778A, eo));

        // panneaux
        List<Row> rows = rows();
        int ci = 0;
        for (Category c : Category.values()) {
            int[] p = POS.get(c);
            int px = p[0], py = p[1];
            float pt = Gfx.clamp01(open * 1.8f - ci * 0.2f);
            ci++;
            if (pt <= 0f) continue;
            float e = Gfx.easeOut(pt);
            var mat = ctx.getMatrices();
            mat.push();
            mat.translate(0f, (1f - e) * -16f, 0f);

            int bottom = bottoms.getOrDefault(c, py + HH);
            Gfx.rrect(ctx, px + 2, py + 3, PW, bottom - py, 5, Gfx.a(0xFF000000, 0.35f * e));
            Gfx.rrect(ctx, px, py, PW, bottom - py, 5, Gfx.a(0xFF111116, 0.95f * e));
            Gfx.rrect(ctx, px, py, PW, HH, 5, Gfx.a(0xFF0A0A0E, e));
            ctx.fill(px + 6, py + HH - 2, px + PW - 6, py + HH - 1, Gfx.a(accent, 0.9f * e));
            Gfx.text(ctx, textRenderer, Text.literal(c.label).formatted(Formatting.BOLD), px + 8, py + 6, Gfx.a(accent, e));
            int on = 0;
            for (Module m : ModuleManager.MODULES) if (m.category == c && m.isEnabled()) on++;
            String cnt = String.valueOf(on);
            Gfx.text(ctx, textRenderer, cnt, px + PW - 8 - textRenderer.getWidth(cnt), py + 6, Gfx.a(0xFF77778A, e));

            for (Row r : rows) if (r.m().category == c) drawRow(ctx, r, mx, my, e, accent, accentDark);
            mat.pop();
        }
    }

    private void drawRow(DrawContext ctx, Row r, int mx, int my, float e, int accent, int accentDark) {
        Module m = r.m();
        if (r.s() == null) {
            boolean hover = r.hit(mx, my);
            m.animHover = Gfx.approach(m.animHover, hover ? 1f : 0f, 14f);
            float tg = Gfx.easeOut(m.animToggle);
            int base = Gfx.mix(0xFF15151A, 0xFF1F1F27, m.animHover);
            int bg = Gfx.mix(base, accentDark, tg);
            Gfx.rrect(ctx, r.x() + 3, r.y() + 1, r.w() - 6, r.h() - 2, 3, Gfx.a(bg, e));
            ctx.fill(r.x() + 3, r.y() + 3, r.x() + 5, r.y() + r.h() - 3, Gfx.a(accent, tg * e));
            Gfx.text(ctx, textRenderer, m.name, r.x() + 10, r.y() + 4, Gfx.a(Gfx.mix(0xFFB8B8C2, accent, tg), e));
            if (!m.settings.isEmpty())
                Gfx.text(ctx, textRenderer, m.expanded ? "-" : "+", r.x() + r.w() - 40, r.y() + 4, Gfx.a(0xFF6A6A75, e));
            int tx = r.x() + r.w() - 28, ty = r.y() + 4;
            Gfx.rrect(ctx, tx, ty, 18, 8, 4, Gfx.a(Gfx.mix(0xFF2A2A32, accent, tg), e));
            Gfx.rrect(ctx, tx + 1 + Math.round(10 * tg), ty + 1, 6, 6, 3, Gfx.a(0xFFFFFFFF, e));
        } else {
            if (r.clipB() <= r.y()) return;
            Setting s = r.s();
            ctx.enableScissor(r.x(), r.y(), r.x() + r.w(), Math.min(r.y() + r.h(), r.clipB()));
            ctx.fill(r.x() + 3, r.y(), r.x() + r.w() - 3, r.y() + r.h(), Gfx.a(0xFF0D0D11, e));
            int tx = r.x() + 8, tw = r.w() - 16;
            float frac = (float) ((s.value - s.min) / (s.max - s.min));
            Gfx.rrect(ctx, tx, r.y() + 3, tw, r.h() - 6, 3, Gfx.a(0xFF1B1B22, e));
            Gfx.rrect(ctx, tx, r.y() + 3, Math.max(5, Math.round(tw * frac)), r.h() - 6, 3, Gfx.a(accent, 0.45f * e));
            Gfx.text(ctx, textRenderer, s.name, tx + 4, r.y() + 4, Gfx.a(0xFFC8C8D0, e));
            String v = s.display();
            Gfx.text(ctx, textRenderer, v, tx + tw - 4 - textRenderer.getWidth(v), r.y() + 4, Gfx.a(0xFFFFFFFF, e));
            ctx.disableScissor();
        }
    }

    private void applySlider(double mx) {
        double f = Math.max(0, Math.min(1, (mx - slX) / (double) slW));
        double v = slider.min + f * (slider.max - slider.min);
        slider.set(Math.round(v / slider.step) * slider.step);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && mx >= 10 && mx < 120 && my >= 10 && my < 28) { Theme.next(); return true; }
        for (Category c : Category.values()) {
            int[] p = POS.get(c);
            if (button == 0 && mx >= p[0] && mx < p[0] + PW && my >= p[1] && my < p[1] + HH) {
                dragCat = c; dragDX = (int) mx - p[0]; dragDY = (int) my - p[1];
                return true;
            }
        }
        for (Row r : rows()) {
            if (!r.hit(mx, my)) continue;
            if (r.s() != null) {
                if (button == 0) { slider = r.s(); slX = r.x() + 8; slW = r.w() - 16; applySlider(mx); }
                return true;
            }
            if (button == 0) { r.m().toggle(); return true; }
            if (button == 1 && !r.m().settings.isEmpty()) { r.m().expanded = !r.m().expanded; return true; }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragCat != null) {
            int[] p = POS.get(dragCat);
            p[0] = Math.max(0, Math.min(width - PW, (int) mx - dragDX));
            p[1] = Math.max(0, Math.min(height - HH, (int) my - dragDY));
            return true;
        }
        if (slider != null) { applySlider(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragCat = null;
        slider = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if ((Character.isLetterOrDigit(chr) || chr == ' ') && query.length() < 16) {
            query += Character.toLowerCase(chr);
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_KP_ADD || keyCode == GLFW.GLFW_KEY_EQUAL) { close(); return true; }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !query.isEmpty()) {
            query = query.substring(0, query.length() - 1);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
