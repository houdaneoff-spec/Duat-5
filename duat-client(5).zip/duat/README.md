# Duat Client (Fabric 1.21.4)

Build : GitHub Actions (onglet Actions) ou `gradle build` avec JDK 21.
Mets le .jar dans mods avec Fabric Loader + Fabric API 1.21.4.

Ecran d accueil au demarrage. Menu en jeu : touche + (pave numerique ou touche =/+).
(clique a gauche / a droite de la valeur pour diminuer / augmenter). Bouton "Theme" en haut a gauche.
Touches : R Sprint | G Fly | B Fullbright | H GlowESP | X Xray | V Freecam | C Zoom
Config sauvegardee dans .minecraft/config/duat.properties a la fermeture du menu.
Tracers (J) : ligne rouge vers chaque entite. AutoDropper : lache l'objet en main. FakeName : /duatnom <pseudo>, visible seulement chez toi.
